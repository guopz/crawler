/**
* @description: gulp-header
* @author: GH
* @versions: 0.0.1
* @update: 2019-04-03 14:25:52
*/
var colument={init:function(){this.page()},page:function(){var i=".subtab_header_hook",n=".u-line",e=function(i,e,s){$(i).on("click","span",function(){var i=$(this).index(),n=$(this).parent().next();$(this).addClass("cur").siblings().removeClass("cur"),"fade"==e?$(n).children("div").eq(i).fadeIn(200).siblings().fadeOut(200):$(n).children("div").eq(i).show().siblings().hide(),s&&s(i)})};e(".tab_header_hook","fade",function(i){$(n).css("left",50*i+"%")}),e(i,"",function(i){})}}.init();