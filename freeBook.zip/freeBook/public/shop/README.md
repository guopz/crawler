 参考网站
> https://m.wangbaowang.org.cn/ 
> 这个网站商城
> http://www.naddc.org.cn
> 首页
> https://m.wangbaowang.org.cn/anhui/shop

技术栈
> JQ + H5